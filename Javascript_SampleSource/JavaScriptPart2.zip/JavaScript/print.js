﻿function print(msg) {
    document.getElementById('message').innerHTML += msg + "<br />";
}