﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Module_Validate_Validate : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        Response.Clear();
        if (Request["txtID"] == "RedPlus")
        {
            Response.Write("false"); // 이미 있는 아이디
        }
        else
        {
            Response.Write("true"); // validation 통과
        }
        Response.End(); 
    }
}