﻿function MessageBox(string) {
    alert(string);
}