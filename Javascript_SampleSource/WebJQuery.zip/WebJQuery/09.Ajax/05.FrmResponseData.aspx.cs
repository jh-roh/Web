﻿using System;

public partial class Ajax_Request_FrmResponseData : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        Response.ContentType = "text/html";
        string html = "<div>안녕<div style=''>" + Request["Msg"] + "," + 
                DateTime.Now.ToLongTimeString() + "</div></div>";
        Response.Clear();
        Response.Write(html);
        Response.End(); 
    }
}
