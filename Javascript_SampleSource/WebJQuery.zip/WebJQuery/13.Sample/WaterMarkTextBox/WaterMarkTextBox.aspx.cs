﻿using System;

public partial class Sample_WaterMarkTextBox_WaterMarkTextBox : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        Response.Write("입력한 아이디 : " + Request["txtUserID"]);
    }
}