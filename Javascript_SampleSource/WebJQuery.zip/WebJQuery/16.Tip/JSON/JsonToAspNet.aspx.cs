﻿using System;
using System.Collections.Generic;

public partial class JsonToAspNet : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        List<견적서> lst = new List<견적서>(); 

        Response.ContentType = "text/html";
        string html = "<div style=''>" + Request["val"] + "<hr />두번째 값 : " + Request["Name"] + "</div><hr />";

        // 넘겨온 값 중 원하는 데이터 뽑아내기...
        string data = Request["val"];

        data = data.Replace("{", "").Replace("}", "");

        html += "<hr />" + data + "<hr />";

        data = data.Replace("],[", "|");

        html += "<hr />" + data + "<hr />";

        string[] arr = data.Split('|');

        html += "<hr />아래는 3개의 자료를 따로 뽑아봄<hr />";
        for (int i = 0; i < arr.Length; i++)
        {
            arr[i] = arr[i].Replace("[", "").Replace("]", "").Replace("\"", "");
            string[] orders = arr[i].Split(',');
            lst.Add(new 견적서 { 품목 = orders[0], 단가 = Convert.ToInt32(orders[1]), 수량 = Convert.ToInt32(orders[2]), 금액 = Convert.ToInt32(orders[3]) });
            html += "<hr />" + arr[i] + "<hr />"; // 이쯤에서 DB에 저장해도 무관...
        }

        Response.Clear();
        Response.Write(html);
        Response.End(); 
    }
}

public class 견적서
{
    public string 품목 { get; set; }
    public int 단가 { get; set; }
    public int 수량 { get; set; }
    public int 금액 { get; set; }
}
